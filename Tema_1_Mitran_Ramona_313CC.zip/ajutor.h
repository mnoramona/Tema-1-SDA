#ifndef aicimaajutla4
#define aicimaajutla4
#include "list.h"

double coeficient(int n, int k);
double valoare(Tlist *left, Tlist *right, int timestamp);

#endif